function continuar(){
    var sobrevivencia = localStorage.getItem("pontos");
    if (sobrevivencia="0"){
        window.location="index.html"
    }else if(sobrevivencia==1){
        window.location="pontinhoskkkk.html"
    }else if(sobrevivencia="11"){
        window.location="naoconfienovermelho.html"
    }else if(sobrevivencia="111"){
        window.location="PULEIIIII.html"
    }else if(sobrevivencia="1111"){
        window.location="quetaljuntardois.html"
    }
}